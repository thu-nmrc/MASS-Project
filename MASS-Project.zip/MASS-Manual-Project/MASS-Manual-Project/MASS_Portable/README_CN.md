# MASS_System

这是 MASS 项目的中文说明文档（README）。该项目为一个轻量级的本地化 LLM 辅助系统，包含前端 UI（`static/`）、后端轻量 HTTP 服务（`server.py`）以及用于构建 Windows 可执行文件的打包脚本（`build_exe.py`）。

## 🎯 使用场景
- 📈 **经济模拟**：竞争、定价策略  
- 🏛️ **政策分析**：政策影响评估  
- 🎮 **游戏 AI**：策略测试、平衡调优  
- 🔬 **社会实验**：群体行为研究  
- 💼 **商业场景**：谈判、危机应对
- 🏢 **组织管理**：层级决策、信息传递
- ⚔️ **军事模拟**：指挥链、战术协调
- 🛒 **顾客旅程**：Touch Point分析、体验优化（NEW!）
- 📋 **项目管理**：阶段推进、里程碑追踪（NEW!）

## 💡 最佳实践
1. **背景规则**：环境、约束、决策/输出格式（理想情况下 >1000 tokens 以便缓存）  
2. **Agent 提示词**：角色、目标、特征、当前状态（200–500 tokens）  
3. **突发事件**：在关键回合触发，量化影响，提供上下文和指导  
4. **成本控制**：从便宜的模型开始；调整 Agent 数量/回合数；考虑缓存


## 目录结构（简要）

- `server.py`：后端 HTTP 服务，暴露 `/api/*` 接口（详见下文）。
- `static/`：前端资源（包含 `index.html`、`js/app.js` 和 `js/i18n.js`）。
- `examples/`：若干示例场景 JSON 用于演示或快速导入。
- `exports/`：运行过程中产生的导出文件，默认包含 `messages.csv`。
- `build_exe.py`：使用 `pyinstaller` 打包为 Windows 可执行。
- `start.bat` / `start.sh`/`mass.exe`：启动开发服务器的脚本示例。

## 快速简介

本仓库实现了一个以 OpenAI 兼容 API 为后端的对话/Agent 管理系统。前端（`static/js/app.js`）负责 Agent 管理、事件控制、导出与配置保存；后端（`server.py`）负责转发请求至 LLM（兼容 OpenAI Chat Completions 接口）、重试策略和导出（CSV/Excel）。

## 主要特性

- 支持多 Agent 配置与自定义 API（per-agent custom API）
- 重试机制：对常见 429/5xx 错误进行重试（可配置重试次数）
- 导出支持：CSV（默认）和 Excel（可选 `openpyxl`）
- 可打包为 Windows 可执行文件（通过 `pyinstaller` 和 `build_exe.py`）

## 环境与依赖

- Python 3.7+（项目基于标准库，Excel 导出依赖 `openpyxl`）
- 若需要打包 Windows 可执行，安装 `pyinstaller`。

安装可选依赖：

```powershell
pip install -r requirements.txt
```

`requirements.txt` 通常包含 `openpyxl` 和 `pyinstaller`（如果需要 Excel 导出或打包）。

## 运行（开发模式）

在项目根目录，Windows 下可直接运行：

```powershell
# 直接运行后端开发服务
python server.py
# 或使用提供的批处理脚本（注意可能需要修改脚本中的 Python 路径）
start.bat
```

默认服务器端口为 8899（可通过环境变量 `MASS_PORT` 修改，如果在 `start` 脚本或 `server.py` 中有覆盖，请以实际代码为准）。

前端静态文件位于 `static/`，打开 `static/index.html` 即可访问前端界面（若后端在本机运行，则前端会通过 fetch 调用后端的 `/api/*` 接口）。

## 后端 API 概览

后端主要暴露以下接口（以 `POST` 请求为主）：

- `/api/config`：保存/更新全局配置（例如 `baseUrl`, `apiKey`, `modelName`, `multiApi`）。
- `/api/test`：测试连接/API 调用的接口，用于验证 `baseUrl` 与 `apiKey` 是否可用。示例请求体包含 `{ baseUrl, apiKey, model, messages }`。
- `/api/complete`：核心的对话/完成接口，后端将构建并转发 `{ model, messages }` 到 `baseUrl + '/chat/completions'`，并返回包含 `status`, `json`, `raw`, `attempts` 等字段的响应。
- `/api/save_message`：保存单条消息到导出记录（CSV）。
- `/api/export`：读取 `exports/messages.csv` 并返回导出的 CSV 文件（默认）。
- `/api/export_excel`：将导出转换为 Excel 文件（依赖 `openpyxl`）。

注意：后端在转发请求时实现了重试策略（常见重试码：429、500、502、503、504），前端可以通过 `maxRetries` 配置与后端交互决定重试次数。

## 前端概览

- `static/js/app.js`：前端主要业务逻辑文件，管理 Agent 对象、事件、运行控制、导出与配置保存/导入。Agent 对象包含字段 `id, name, prompt, useCustomApi, customBaseUrl, customApiKey, customModel, subordinates, includeSubSubordinates, returnDefaultEnabled`。
- `static/js/i18n.js`：国际化文本（支持 `zh-CN` 与 `en`），修改 UI 文本请同步更新此文件。

缓存与多 API 模式说明：

- 当 `multiApi === false` 且 `disableCache === false` 时，前端会把背景规则作为可缓存的 `system` 消息发送（使用 `cache_control` 标记）。启用多 API 模式会自动禁用缓存（两者互斥）。

## 示例

仓库包含多个示例场景（`examples/`），例如：

- `scenario_simple_test.json`
- `scenario_with_events.json`

这些示例可以在前端界面中导入以快速构造测试场景。

API 测试请求示例（用于 `/api/test`）：

```json
POST /api/test
{
  "baseUrl": "https://api.openai.com/v1",
  "apiKey": "sk-...",
  "model": "gpt-4",
  "messages": [{"role":"system","content":"ping"},{"role":"user","content":"ping"}]
}
```

## 导出与 CSV 格式

- 后端会将交互记录写入 `exports/messages.csv`，`/api/export` 读取该 CSV 并生成 `export_{n}.csv` 返回给前端。
- Excel 导出需要 `openpyxl`，如果不存在则 Excel 功能不可用。
- 请勿随意修改 CSV 列顺序，否则可能导致 `export_csv` / `export_excel` 不兼容前端导出逻辑。

## 打包为 Windows 可执行

在需要将项目打包为单文件/可移植版本时，使用 `pyinstaller`：

```powershell
pip install pyinstaller
python build_exe.py
```

`build_exe.py` 会使用 `pyinstaller` 生成 Windows 可执行文件。构建结果会写入 `build/` 目录（示例已包含 `build/MASS/`）。

## 维护与扩展建议

- 修改后端接口或响应格式前，请先在 `static/js/app.js` 中定位对应 `fetch` 使用处并同步更新前端。
- 增加新后端端点时，请在 `server.py` 的 `RequestHandler.do_POST` 中添加路由，并更新 `static/js/app.js` 的相应 `fetch` 调用与错误提示。
- 若扩展 per-agent API 功能，遵循前端 `agent.useCustomApi` 字段与 UI（`editAgent` / `configAgentApi`）。

## 快速故障排查

- 若后端无法连接 LLM，检查 `baseUrl` 与 `apiKey` 是否正确，并尝试调用 `/api/test` 查看具体错误码。
- 若导出 Excel 报错，确认已安装 `openpyxl`。
- 若打包失败，请确认 `pyinstaller` 版本兼容并查看 `build/` 下的日志文件。


## 📚 学术引用（强烈建议学术使用）

如果您在学术或科学研究中使用此**方法**或**软件**，请引用：

Hu, Xiaoli; Shen, Yang; You, Keke (2025).  
*Multi-Agent Social Simulation: An Experimental Framework for Language-Native Social Experiments.*  
Agents4Science 2025 Workshop (Stanford), October 22, 2025.  
Available at: https://openreview.net/forum?id=emsnDnmtYP#discussion

**BibTeX**
```bibtex
@inproceedings{HuShenYou2025MASS,
  author    = {Xiaoli Hu and Yang Shen and Keke You},
  title     = {Multi-Agent Social Simulation: An Experimental Framework for Language-Native Social Experiments},
  booktitle = {Agents4Science 2025 Workshop},
  address   = {Stanford},
  year      = {2025},
  month     = {October},
  url       = {https://openreview.net/forum?id=emsnDnmtYP#discussion}
}
```

仓库包含 `CITATION.cff`，可被学术引用工具自动识别。

## 🤝 贡献指南
欢迎贡献——请提交 pull request。

## 📄 许可证
本项目基于 **MIT 许可证** 发布。  
源自 **胡晓李 (Xiaoli Hu)** 的 MASS 项目。  
详见 [LICENSE](./LICENSE) 文件。
